/*----------------------------------------------------*\
|                   BY MARSELSHOW					   |
\*----------------------------------------------------*/
-(RUS_RU)-
| Это вирус сделан, за долгое время (почти долгое)
| Тут еще есть баги не аккуратности и т.д.,
| Самое главное то что вирус написан только на VBS и BAT по этому я так и его назвал)
| я думаю всо сказал то что хотел

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
----------------------------------------------------
\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

-(English_ENG)-
| This virus has been made for a long time (almost a long time)
| There are still bugs of not accuracy, etc.,
| The most important thing is that the virus is written only in VBS and BAT, that's why I called it | that)
| I think I said what I wanted

#Run(Запуск)
open vbat(bymarselshow).exe
(code) open: start.bat 
Ver([1.0])

#Contacts (=D)
VK: https:\\vk.com\marselshowyoutube
YouTube Channel: https://www.youtube.com/channel/UCYonJcWnTrgUiymM6r8XJ2Q
Qiwi: +79041926761
Telegram: +79041926761
Discord: MarselShow#5401